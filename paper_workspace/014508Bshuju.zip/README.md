# 支撑材料 — 014508 B题

## 目录结构

```
├── README.md              # 本文件
├── code/                  # 全部可运行源代码（9个.py）
├── data/                  # 赛题PDF + 外部参考数据说明
├── results/               # 中间计算结果（CSV/JSON）
├── figures/               # 论文全部插图（300dpi PNG）
└── latex/                 # LaTeX 论文源码（12个.tex，完整可编译）
```

## 外部参考数据来源

论文中引用但未以PDF形式纳入的外部参考资料：

| 资料 | 用途 | 获取方式 |
|------|------|----------|
| 《中国老龄事业发展报告》 | §2.2 人口结构校验：城市社区自理老人占比65-70% | 中国老龄科学研究中心官网 |
| Church & ReVelle (1974) | MCLP最大覆盖选址理论基础 | doi:10.1007/BF01942293 |
| McCormick (1976) | 双线性项凸包络线性化 | doi:10.1007/BF01580665 |
| Ramsey (1927) | 三级交叉补贴定价理论 | doi:10.2307/2224098 |
| Leslie (1945) | 种群矩阵模型 | doi:10.2307/2332185 |
| Daskin (1995) | 网络与离散选址 | Wiley, ISBN:978-0471018377 |
| Wolsey (1998) | 整数规划理论 | Wiley, ISBN:978-0471283669 |
| Bertsimas et al. (2011) | 鲁棒优化理论 | doi:10.1137/1.9781611973369 |

## 赛题附件数据

附件1-5（Excel）为竞赛组委会提供的原始数据，按规范未纳入本压缩包。代码通过 `data/` 目录下的路径常量自动加载，评阅时请将附件1-5置于 `data/` 目录下运行。

## 使用说明

```bash
# 安装依赖
pip install numpy pandas matplotlib seaborn networkx pulp openpyxl scipy

# 运行求解（按Q1→Q4顺序，各脚本可独立运行）
python code/solve_q1.py
python code/solve_q2.py
python code/solve_q3.py
python code/solve_q4_sensitivity.py

# 重新生成全部论文插图
python code/regenerate_all_figures.py

# 编译论文（需 TeX Live 2024+）
cd latex && xelatex main_backup.tex && xelatex main_backup.tex && xelatex main_backup.tex
```

## 环境

- Python 3.10+ | LaTeX: xelatex (TeX Live 2024+) | 求解器: CBC (COIN-OR)
- 字体: SimSun, SimHei, SimKai, FangSong（Windows 10/11 自带）
