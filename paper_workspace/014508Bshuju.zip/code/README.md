# code/ — 全部可运行源代码

| 文件 | 行数 | 功能 |
|------|------|------|
| `config.py` | ~80 | 全局路径配置与参数常量 |
| `solve_q1.py` | 380 | Q1: 增生型Markov链人口预测 + Leslie矩阵三角校验 |
| `solve_q2.py` | 560 | Q2: MILP-MCLP-ES选址-规模优化（Big-M + McCormick包络） |
| `solve_q3.py` | 360 | Q3: 词典序MILP差异化定价 + 三层交叉补贴核算 |
| `solve_q4_sensitivity.py` | 654 | Q4: 三场景灵敏度分析 + 多维韧性矩阵 |
| `regenerate_all_figures.py` | ~730 | 统一生成论文全部图表（Academic Noir配色，300dpi） |
| `generate_extra_figures.py` | ~600 | 韧性热力图、雷达图等补充可视化 |
| `generate_q4_combined.py` | ~90 | Q4灵敏度全景对比图 |
| `fix_abstract.py` | ~90 | 摘要微调辅助脚本 |

## 运行顺序

```
solve_q1.py → results/q1_*.csv
solve_q2.py → results/q2_*.csv/json
solve_q3.py → results/q3_*.csv
solve_q4_sensitivity.py → results/q4_*.csv
regenerate_all_figures.py → figures/*.png
```

## 依赖

```
pip install numpy pandas matplotlib seaborn networkx pulp openpyxl scipy
```

## 求解器

Q2/Q3/Q4 使用开源 CBC（COIN-OR Branch-and-Cut），通过 PuLP 接口调用。三级降级链：CBC → Gurobi → Mosek（若安装商业求解器则自动使用）。
