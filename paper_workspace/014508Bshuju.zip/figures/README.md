# figures/ — 论文全部插图（300dpi PNG, Academic Noir配色）

| 文件名 | 对应内容 | 论文位置 |
|--------|----------|----------|
| `figure_tech_route.png` | 技术路线：四阶段递进框架 | §1.4 图1 |
| `figure_q1_total_trend.png` | 三类老人5年演化轨迹 | §5.1 图2 |
| `figure_q1_stacked_bar.png` | 基年 vs 第5年末人口结构堆叠 | §5.1 图3 |
| `figure_q2_network.png` | 最优选址-规模空间网络（F大型+H/J中型） | §5.2 图5 |
| `figure_q2_station_load.png` | 三站日负荷与利用率对比 | §5.2 图6 |
| `figure_q3_pricing_comparison.png` | 基准价 vs 最优定价对比 | §5.3 图7 |
| `figure_q3_cross_subsidy.png` | 三层交叉补贴流向图 | 附录 |
| `figure_q3_profit_breakdown.png` | 站点年利润分项分解 | 附录 |
| `figure_q4_sensitivity_combined.png` | 三场景覆盖率/满意度/利润全景 | §5.4 图8 |
| `figure_q4_resilience_heatmap.png` | 三场景四维度韧性热力图 | §5.4 图9 |
| `figure_q4_resilience_radar.png` | 多维度鲁棒性雷达图 | §5.4 图10 |
| `figure_q4_coverage.png` | 三场景覆盖率独立对比 | 附录 |
| `figure_q4_satisfaction.png` | 三场景满意度独立对比 | 附录 |
| `figure_q4_profit.png` | 三场景年利润独立对比 | 附录 |

## 重新生成

```bash
cd ../code && python regenerate_all_figures.py
```
