# latex/ — 论文 LaTeX 源码（xelatex 三编）

## 编译

```bash
xelatex main_backup.tex && xelatex main_backup.tex && xelatex main_backup.tex
```

## 文件清单

| 文件 | 内容 |
|------|------|
| `main_backup.tex` | 主文件：封面 + 摘要 + 正文 + 参考文献 + 附录 |
| `section_1_problem_background.tex` | §1 问题背景与重述 |
| `section_2_data_preprocessing.tex` | §2 数据源溯源与特征工程 |
| `section_3_model_formulation.tex` | §3 模型构建（Markov/Leslie/MILP/Big-M/McCormick） |
| `section_4_assumptions.tex` | §4 模型假设与合理性论证 |
| `section_5_1_q1_results.tex` | §5.1 Q1 人口预测结果 |
| `section_5_2_q2_results.tex` | §5.2 Q2 选址-规模优化结果 |
| `section_5_3_q3_results.tex` | §5.3 Q3 定价与补贴优化结果 |
| `section_5_4_q4_robustness.tex` | §5.4 Q4 灵敏度与鲁棒性分析 |
| `section_6_model_evaluation.tex` | §6 模型评价与推广 |
| `section_7_engineering_recommendations.tex` | §7 工程实施建议 |
| `appendix_code.tex` | 附录：算法伪代码 + McCormick推导 + 完整代码 + 补充表 |

## 环境

- TeX Live 2024+ / xelatex
- 字体：SimSun, SimHei, SimKai, FangSong
- 页面：A4, 2.5cm页边距, 12pt宋体小四
