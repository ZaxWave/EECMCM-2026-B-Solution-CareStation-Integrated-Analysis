# results/ — 中间计算结果

## Q1 人口预测

| 文件 | 内容 |
|------|------|
| `q1_final_population.csv` | 10小区第5年末三类老人数 + 60+总人口 |
| `q1_service_demand.csv` | 各小区×老人类型×服务项目的实际需求（消费约束后） |
| `q1_summary_stats.csv` | 全区域汇总：总人口、失能率、消费约束削减率 |

## Q2 选址优化

| 文件 | 内容 |
|------|------|
| `q2_baseline.json` | 求解参数（seed=42, time_limit=120s, gap<1%） |
| `q2_optimal_location.csv` | F(大型)+H(中型)+J(中型)，覆盖范围，建设/运营成本 |

## Q3 定价优化

| 文件 | 内容 |
|------|------|
| `q3_optimal_pricing.csv` | 6项服务基准价 vs 最优定价 vs S3满意度 |
| `q3_station_profit.csv` | 各站点年营收/补贴/成本/利润/利润率（F站8.0%紧约束） |

## Q4 灵敏度分析

| 文件 | 内容 |
|------|------|
| `q4_sensitivity_summary.csv` | 三场景覆盖率/满意度/利润/韧性系数 |

## 数据流

```
q1_*.csv → Q2输入 → q2_*.csv/json → Q3固定选址 → q3_*.csv
                                            ↓
                                   Q4参数扫描 → q4_*.csv
```
